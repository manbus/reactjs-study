## 问题

1. yar add --dev node-sass 失败
   yar add  --dev node-sass --registry="http://npm.taobao.org"

2. rror: ENOENT: no such file or directory, scandir
'D:\IdeaWork\code-front-jet\node_modules\.npminstall\node-sass\3.7.0\node-sass\vendor'
 解决编译scss文件时，失败的问题
npm rebuild node-sass


3.  多 tab切换时，需要清除掉手势滑动切换，否则会导致长页面无法上滑查看下边的内容

4. 图片要使用一些代替图片，防止图片没有加载时页面的混乱

5. 父级元素使用了transfrom，导致元素的position:fixed失效？？？
