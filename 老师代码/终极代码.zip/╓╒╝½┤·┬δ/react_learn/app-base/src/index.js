import React from 'react';
import ReactDOM from 'react-dom';

//引入样式表，后期会经过编译转换
import './styles/index.css'

import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));
