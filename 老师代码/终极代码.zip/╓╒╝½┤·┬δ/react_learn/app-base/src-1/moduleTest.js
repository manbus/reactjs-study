

export default function(){
  console.log("helloworld");
};

//let 没有变量声明提升
export  let name = 'lisi';
export  let age = 20;
