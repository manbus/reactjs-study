
## react

```
react 组件的条件渲染，按照if分支语句、 逻辑操作，判断要渲染那个组件
react 中 列表项中，需要给每一个列表项添加 key, 用于react的性能优化, key的具体描述看文档

react 中form表单， 针对 textarea, select 做了优化，使用value和state配合即可

状态提升： 兄弟组件如果有共享的state，那么就将该state设置到他们共同的父组件上(通信方便)

```
